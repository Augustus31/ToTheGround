using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using System;

public class blockScript : MonoBehaviour
{
    public int state;
    public double progressInState;
    public SpriteRenderer renderer;
    public bool burnCorActive = false;
    public GameObject controller; 
    public GameController controllerScript;
    public int[] windFactor;
    public float[] burnFactor;
    public int currentWindFactor = 0;
    public float currentBurnFactor = 0;
    GameObject debugCircle;
    public float scaleFactor;
    public int level;
    public GameObject percentometerPrefab;
    public GameObject percentometer;
    public TMPro.TextMeshProUGUI text;
    public GameObject renderCanvas;
    public float tickSpeed;
    public int suppress;
    Camera cam;
    // Start is called before the first frame update
    void Start()
    {
        suppress = 0;
        state = 0;
        progressInState = 0;
        tickSpeed = 0.1f;
        renderCanvas = GameObject.Find("UICanvas");
        cam = Camera.main;
        renderer = GetComponent<SpriteRenderer>();
        controller = GameObject.Find("Controller");
        controllerScript = controller.GetComponent<GameController>();
        percentometerPrefab = Resources.Load("percentometer") as GameObject;
        percentometer = Instantiate(percentometerPrefab, convertToScreenCenter(renderer.bounds.center), Quaternion.identity);
        text = percentometer.GetComponent<TMPro.TextMeshProUGUI>();
        text.transform.SetParent(renderCanvas.transform, false);
        level = 1;
        windFactor = new int [4];
        windFactor[0] = 20;
        windFactor[1] = 12;
        windFactor[2] = 8;
        windFactor[3] = 6;
        burnFactor = new float[4];
        burnFactor[0] = 11.9f;
        burnFactor[1] = 7.7f;
        burnFactor[2] = 8.2f;
        burnFactor[3] = 6f;
        debugCircle = Resources.Load("debugCircle") as GameObject;
        StartCoroutine(burnCoroutine());
        scaleFactor = 5f / 1080f;
        print(scaleFactor);



        //print(cam.WorldToScreenPoint(renderer.bounds.center));
        //print((Vector3)controllerScript.dirDict[controllerScript.windDir]);

    }

    // Update is called once per frame
    void Update()
    {
        //text.text = UnityEngine.Random.Range(0, 2).ToString();
        level = GameController.level;
        text.text = ((int)(progressInState + 0.5)).ToString();
        
        if (state == 0)
        {
            text.enabled = false;
            renderer.color = new Color(160/255f, 207/255f, 159/255f);
        }
        if(state == 1)
        {
            text.enabled = true;
            text.color = new Color(158 / 255f, 110 / 255f, 38 / 255f);
            renderer.color = new Color(237/255f, 137/255f, 14/255f);
        }
        if (state == 2)
        {
            text.enabled = true;
            text.color = new Color(135 / 255f, 51 / 255f, 45 / 255f);
            renderer.color = new Color(252/255f, 65/255f, 3/255f);
        }
        if(state == 3)
        {
            text.enabled = false;
            renderer.color = new Color(0,0,0);
        }
        if(state == 1 && progressInState >= 100)
        {
            state = 2;
            progressInState = 100;
        }
        if (state == 1 && progressInState <= 0)
        {
            state = 0;
            progressInState = 0;
        }
        if (state == 2 && progressInState <= 0)
        {
            state = 3;
            progressInState = 0;
        }
    }
    public IEnumerator burnCoroutine()
    {
        burnCorActive = true;
        while (burnCorActive)
        {
            //print(level);
            currentWindFactor = windFactor[level - 1];
            currentBurnFactor = burnFactor[level - 1]*tickSpeed;
            try
            {
                if (suppress > 0)
                {
                    if(state == 1)
                    {
                        progressInState -= 1.2 * suppress * tickSpeed;
                    }
                    if(state == 2)
                    {
                        progressInState -= 0.6 * suppress * tickSpeed;
                    }
                }
                if(state == 2)
                {
                    progressInState -= currentBurnFactor*0.25;
                }
                if (state == 1)
                {
                    progressInState += tickSpeed*2*(-0.5 + progressInState / 100);
                }
                foreach (GameObject block in controllerScript.blocks)
                {
                    if (!UnityEngine.Object.ReferenceEquals(block, this))
                    {
                        
                        Vector3 closestPoint = renderer.bounds.ClosestPoint(block.GetComponent<SpriteRenderer>().bounds.ClosestPoint(renderer.bounds.center));
                        if (level == 3)
                        {
                            closestPoint = renderer.bounds.ClosestPoint(block.GetComponent<SpriteRenderer>().bounds.center);
                        }
                        //Instantiate(debugCircle, closestPoint + scaleFactor * (Vector3)controllerScript.dirDict[controllerScript.windDir] * controllerScript.windSpeed * currentWindFactor + new Vector3(0,0,-1), Quaternion.identity);
                        //print(((Vector3)controllerScript.dirDict[controllerScript.windDir] * controllerScript.windSpeed * currentWindFactor));
                        //print(convertToWorld((Vector3)controllerScript.dirDict[controllerScript.windDir] * controllerScript.windSpeed * currentWindFactor));
                        for (int i = 4; i > 0; i--)
                        {
                            if (block.GetComponent<blockScript>().state == 2 && block.GetComponent<SpriteRenderer>().bounds.Contains(closestPoint + i / 4f * scaleFactor * (Vector3)controllerScript.dirDict[controllerScript.windDir] * controllerScript.windSpeed * currentWindFactor))
                            {
                                if (state == 0)
                                {
                                    state = 1;
                                }

                                if (state == 1)
                                {
                                    progressInState += currentBurnFactor*1/(Mathf.Log10(Vector3.Distance(convertToScreen(closestPoint), convertToScreen(block.GetComponent<SpriteRenderer>().bounds.ClosestPoint(renderer.bounds.center))))+0.15f) * controllerScript.windSpeed / 20;
                                }
                                break;
                            }
                        }
                        
                    }
                }
            }
            catch(Exception e)
            {
                print(e.ToString());
            }
            yield return new WaitForSeconds(tickSpeed);
        }
        
    }
    public Vector3 convertToScreen(Vector3 a)
    {
        return cam.WorldToScreenPoint(a);
    }
    public Vector3 convertToWorld(Vector3 a)
    {
        return cam.ScreenToWorldPoint(a);
    }
    public Vector3 convertToScreenCenter(Vector3 a)
    {
        return cam.WorldToScreenPoint(a) + new Vector3(-1 * cam.scaledPixelWidth/2, -1 * cam.scaledPixelHeight/2, 0);
    }
}
