using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class powerBarScript : MonoBehaviour
{
    // Start is called before the first frame update
    public Scrollbar scrollbar;
    public GameObject controller;
    public GameController controllerScript;
    void Start()
    {
        scrollbar = GetComponent<Scrollbar>();
        controller = GameObject.Find("Controller");
        controllerScript = controller.GetComponent<GameController>();
    }

    // Update is called once per frame
    void Update()
    {
        scrollbar.size = controllerScript.power / 100;
    }
}
