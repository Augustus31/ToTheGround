using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class firemanScript : MonoBehaviour
{
    public GameObject fronteira1;
    public GameObject fronteira2;
    public GameObject fronteira3;
    public GameObject fronteira4;
    public GameObject fronteira5;
    public Renderer renderer;
    public GameObject arrow;
    public bool sim;
    public IDictionary<GameObject, bool> status;


    // Start is called before the first frame update
    void Start()
    {
        sim = true;
        renderer = GetComponent<Renderer>();
        arrow = (GameObject)Resources.Load("blueArrow");
        GameObject[] asFronteiras = { fronteira1, fronteira2, fronteira3, fronteira4, fronteira5};
        float cPosX = renderer.bounds.center.x;
        float cPosY = renderer.bounds.center.y;
        float[] averagem = { 0, 0 };
        int nonNull = 0;
        status = new Dictionary<GameObject, bool>();

        foreach (GameObject fronteira in asFronteiras)
        {
            if (fronteira != null)
            {
                status.Add(fronteira, false);
            }

        }
        foreach (GameObject fronteira in asFronteiras){
            if(fronteira != null)
            {
                averagem[0] += fronteira.GetComponent<Renderer>().bounds.ClosestPoint(renderer.bounds.center).x;
                averagem[1] += fronteira.GetComponent<Renderer>().bounds.ClosestPoint(renderer.bounds.center).y;
                nonNull++;
            }
            
        }
        transform.position = new Vector3(averagem[0] / nonNull, averagem[1] / nonNull, renderer.bounds.center.z);
    }

    // Update is called once per frame
    void Update()
    {
        GameObject[] asFronteiras = { fronteira1, fronteira2, fronteira3, fronteira4, fronteira5 };
        int fN = 0;
        foreach (GameObject fronteira in asFronteiras)
        {
            if (fronteira != null)
            {
                if(fronteira.GetComponent<blockScript>().state < 2)
                {
                    fN++;
                }
                if(fronteira.GetComponent<blockScript>().state == 1 || fronteira.GetComponent<blockScript>().state == 2)
                {
                    if(status[fronteira] == false)
                    {
                        StartCoroutine(DrawLine(fronteira));
                    }
                    //fronteira.GetComponent<blockScript>().progressInState -= 1.3 * Time.deltaTime;
                }
            }

        }
        if (fN == 0)
        {
            sim = false;
            renderer.enabled = false;
        }
    }

    public IEnumerator DrawLine(GameObject obj)
    {
        status[obj] = true;
        obj.GetComponent<blockScript>().suppress += 1;

        float arctan = (obj.GetComponent<Renderer>().bounds.center.y - renderer.bounds.center.y) / (obj.GetComponent<Renderer>().bounds.center.x - renderer.bounds.center.x);
        float angle = Mathf.Rad2Deg* Mathf.Atan(arctan);
        angle = 90 - angle;
        if (obj.GetComponent<Renderer>().bounds.center.x - renderer.bounds.center.x < 0)
        {
            angle += 180;
        }
        GameObject arr = Instantiate(arrow, renderer.bounds.center, Quaternion.Euler(new Vector3(0, 0, 360-angle)));
        while(sim && (obj.GetComponent<blockScript>().state == 1 || obj.GetComponent<blockScript>().state == 2))
        {
            yield return new WaitForSeconds(0.1f);
        }
        GameObject.Destroy(arr);
        status[obj] = false;
        obj.GetComponent<blockScript>().suppress -= 1;
    }
}
