using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class dirTextScript : MonoBehaviour
{
    // Start is called before the first frame update
    public TMPro.TextMeshProUGUI text;
    public GameObject controller;
    public GameController controllerScript;
    void Start()
    {
        text = GetComponent<TMPro.TextMeshProUGUI>();
        controller = GameObject.Find("Controller");
        controllerScript = controller.GetComponent<GameController>();
    }

    // Update is called once per frame
    void Update()
    {
        
    }
    public void northCall()
    {
        text.text = "North";
        controllerScript.windDir = 1;
    }
    public void southCall()
    {
        text.text = "South";
        controllerScript.windDir = 3;
    }
    public void eastCall()
    {
        text.text = "East";
        controllerScript.windDir = 2;
    }
    public void westCall()
    {
        text.text = "West";
        controllerScript.windDir = 4;
    }
}
