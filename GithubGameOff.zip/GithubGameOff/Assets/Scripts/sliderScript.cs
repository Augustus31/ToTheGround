using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class sliderScript : MonoBehaviour
{
    // Start is called before the first frame update
    public Slider slider;
    public GameObject controller;
    public GameController controllerScript;
    void Start()
    {
        slider = GetComponent<Slider>();
        controller = GameObject.Find("Controller");
        controllerScript = controller.GetComponent<GameController>();
    }

    // Update is called once per frame
    void Update()
    {
        
    }
    public void OnValueChanged(float newValue)
    {
        try
        {
            controllerScript.windSpeed = (int)(newValue + 0.1f);
        }
        catch
        {
            
        }

    }
}
