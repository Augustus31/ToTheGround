using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class speedTextScript : MonoBehaviour
{
    // Start is called before the first frame update
    public GameObject controller;
    public GameController controllerScript;
    public TMPro.TextMeshProUGUI text;
    void Start()
    {
        text = GetComponent<TMPro.TextMeshProUGUI>();
        print(text.text);
        controller = GameObject.Find("Controller");
        controllerScript = controller.GetComponent<GameController>();
    }

    // Update is called once per frame
    void Update()
    {
        text.text = controllerScript.windSpeed.ToString();
    }
}
