using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;
using UnityEngine.UI;

public class GameController : MonoBehaviour
{
    public int windSpeed;
    public int windDir;
    public static int level;
    public float power;
    public GameObject[] blocks;
    Slider slider;
    public IDictionary dirDict = new Dictionary<int, Vector3>();
    public AudioSource audiosource;
    public bool transition;
    public bool debugLU;
    // Start is called before the first frame update
    void Start()
    {
        debugLU = false;
        Scene currentScene = SceneManager.GetActiveScene();
        string sceneName = currentScene.name;
        if (sceneName.Equals("Level1"))
        {
            level = 1;
        }
        
        transition = false;

        dirDict.Add(1, new Vector3(0, -1, 0));
        dirDict.Add(2, new Vector3(-1, 0, 0));
        dirDict.Add(3, new Vector3(0, 1, 0));
        dirDict.Add(4, new Vector3(1, 0, 0));

        slider = GameObject.Find("Slider").GetComponent<Slider>();
        audiosource = GetComponent<AudioSource>();
        audiosource.playOnAwake = false;
        audiosource.volume = 1;

        windSpeed = 0;
        windDir = 1;
        power = 100;
        blocks = GameObject.FindGameObjectsWithTag("block"); 

        if(level == 2)
        {
            GameObject stockton = GameObject.Find("stockton");
            stockton.GetComponent<blockScript>().state = 2;
            stockton.GetComponent<blockScript>().progressInState = 100;
        }
        if (level == 4)
        {
            GameObject saude = GameObject.Find("saude");
            saude.GetComponent<blockScript>().state = 2;
            saude.GetComponent<blockScript>().progressInState = 100;
        }
        if (level == 3)
        {
            GameObject gamlastan = GameObject.Find("gamlastan");
            gamlastan.GetComponent<blockScript>().state = 2;
            gamlastan.GetComponent<blockScript>().progressInState = 100;
        }

    }

    // Update is called once per frame
    void Update()
    {
        //print(level);
        bool alive = false;
        foreach(GameObject block in blocks)
        {
            if(block.GetComponent<blockScript>().state <= 1)
            {
                alive = true;
            }
        }
        if (!alive && !transition && Time.timeSinceLevelLoad > 1 || debugLU)
        {
            debugLU = false;
            transition = true;
            StartCoroutine(levelUp());
        }
        if(windSpeed <= 12)
        {
            power += Time.deltaTime * (18 - 36f / (1 + Mathf.Exp((-1f / 11f) * (windSpeed - 12))));
        }
        else
        {
            power += Time.deltaTime * (-1 * Mathf.Exp((windSpeed - 12) / 13f) + 1);
        }
        

        if(power < 0)
        {
            slider.value = 5;
            power = 0;
        }

        if(power > 100)
        {
            power = 100;
        }
    }
    public IEnumerator levelUp()
    {
        audiosource.Play();
        yield return new WaitForSeconds(3.5f);
        level = level + 1;
        if(level == 2)
        {
            SceneManager.LoadSceneAsync("Level2");
        }
        if (level == 3)
        {
            SceneManager.LoadSceneAsync("Level3");
        }
        if (level == 4)
        {
            SceneManager.LoadSceneAsync("Level4");
        }
        if (level == 5)
        {
            SceneManager.LoadSceneAsync("end");
        }
    }
}
