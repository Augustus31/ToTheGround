using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class tutorialScript : MonoBehaviour
{
    // Start is called before the first frame update
    public TMPro.TextMeshProUGUI text;
    public bool clicked;
    void Start()
    {
        text = GetComponent<TMPro.TextMeshProUGUI>();
        clicked = false;
        text.text = "Welcome to Tutorialtown! Click anywhere to begin.";
    }

    // Update is called once per frame
    void Update()
    {
        
    }

    public void OnMouseDown()
    {
        if (!clicked)
        {
            clicked = true;
            text.text = "A block is on fire! Spread it by controlling the wind.";
            GameObject.Find("BL").GetComponent<blockScript>().progressInState = 100;
            GameObject.Find("BL").GetComponent<blockScript>().state = 2;
            StartCoroutine(tutorializer());
        }
    }

    public IEnumerator tutorializer()
    {
        yield return new WaitForSeconds(9);
        text.text = "Watch out for firemen! Burn the area around them to eliminate them.";
        yield return new WaitForSeconds(9);
        text.text = "Burn down every block to win.";
    }
}
